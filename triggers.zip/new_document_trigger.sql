-- Trigger: new_document_trigger

-- DROP TRIGGER IF EXISTS new_document_trigger ON public."FE_POS";

CREATE TRIGGER new_document_trigger
    AFTER INSERT OR UPDATE 
    ON public."FE_POS"
    FOR EACH ROW
    EXECUTE FUNCTION public.notify_newdocument();