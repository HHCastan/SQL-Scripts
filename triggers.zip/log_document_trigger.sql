-- Trigger: log_document_trigger

-- DROP TRIGGER IF EXISTS log_document_trigger ON public."FE_POS";

CREATE TRIGGER log_document_trigger
    AFTER INSERT OR UPDATE 
    ON public."FE_POS"
    FOR EACH ROW
    EXECUTE FUNCTION public.log_document();